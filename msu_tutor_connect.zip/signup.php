<?php
require_once 'common.php';
$controller = new AuthController();
$controller->signup();
