<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'msu_tutor_connect');
define('DB_USER', 'msu_tutor_user');
define('DB_PASS', 'StrongPassword123!');
