<?php
require_once 'common.php';
$controller = new HomeController();
$controller->index();
