<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'msu_tutor_connect');
define('DB_USER', 'root');
define('DB_PASS', 'root');
